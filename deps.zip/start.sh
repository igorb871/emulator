#!/bin/sh

erl $@ -pa deps/*/ebin ebin
